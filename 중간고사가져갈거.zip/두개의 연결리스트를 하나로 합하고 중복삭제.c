#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#include<stdlib.h>
#include<conio.h>
#define MAX 100
void insert(int input);
void print();

typedef struct node {
	int key;
	struct node* next;
}NODE;

NODE* start = NULL;

int main() {
	int input = 0, list[MAX], k = 0, temp = 0;

	FILE* fp = fopen("in1.txt", "r");
	if (fp == NULL)
	{
		printf("������ �����ϴ�.\n���α׷��� ���� �մϴ�.\n");
		return 0;
	}
	else
	{
		int i = 0;
		printf("in1.txt\n");
		while (!feof(fp))
		{
			fscanf(fp, "%d", &list[i]);
			printf("%d ", list[i]);
			i++;
		}
		k = i;
	}
	fclose(fp);

	FILE* fp_2 = fopen("in2.txt", "r");
	if (fp_2 == NULL)
	{
		printf("������ �����ϴ�.\n���α׷��� ���� �մϴ�.\n");
		return 0;
	}
	else
	{
		printf("\n\nin2.txt\n");
		while (!feof(fp_2))
		{
			fscanf(fp, "%d", &list[k]);
			printf("%d ", list[k]);
			k++;
		}
	}

	printf("\n\n");

	for (int a = 0; a < k; a++)
	{
		for (int b = 0; b < k - 1 - a; b++)
		{
			if (list[b] > list[b + 1])
			{
				temp = list[b];
				list[b] = list[b + 1];
				list[b + 1] = temp;
			}
		}
	}

	for (int a = 0; a < k; a++)
	{
		if (list[a] == list[a + 1])
			continue;
		else
			insert(list[a]);
	}
	fclose(fp_2);


	print();


	return 0;
}
void insert(int input) {
	NODE* newnode, * cur;
	newnode = (NODE*)malloc(sizeof(NODE));
	newnode->next = NULL;
	newnode->key = input;
	cur = start;
	if (start == NULL) {
		start = newnode;
		return;
	}
	else if (start->key > newnode->key) {
		newnode->next = start;
		start = newnode;
		return;
	}
	else
	{
		while (cur->next != NULL) {
			if (cur->next->key > newnode->key) {
				newnode->next = cur->next;
				cur->next = newnode;
				return;
			}
			cur = cur->next;
		}
	}
	cur->next = newnode;
}


void print() {
	NODE* cur;
	cur = start;
	while (cur->next != NULL) {
		printf("%d ", cur->key);
		cur = cur->next;
	}
	printf("%d \n", cur->key);
}