#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>

#define MAX_ROW 100
#define MAX_COL 100
#define MAX_STACK 100
#define SIZE 5
#define TRUE 1
#define FALSE 0

int maze[MAX_ROW][MAX_COL] = { 1 };
int mark[MAX_ROW][MAX_COL] = { 0 };
int top = -1, EXIT_ROW, EXIT_COL;


typedef struct
{
	short int vert;
	short int horiz;
} offsets;
offsets move[8] = { -1,0,-1,1,0,1,1,1,1,0,1,-1,0,-1,-1,-1 };

typedef struct
{
	short int row;
	short int col;
	short int dir;
} element;


element stack[MAX_STACK];

int stackFull() { // ������ �� á���� Ȯ���ϴ� �Լ�
	if (top >= SIZE - 1) {
		return 1;
	}
	return 0;
}

int stackEmpty() // ������ ������� Ȯ���ϴ� �Լ�
{
	if (top == -1) {
		return 1;
	}
	return 0;
}

void push(element data) { // ������ �о�ִ� �Լ�
	if (!stackFull()) {
		top++;
		stack[top] = data;
	}
}

element pop() { // ������ �����ϴ� �Լ�
	if (!stackEmpty()) {
		element temp = stack[top];
		top--;
		return temp;
	}
}


void path(void)
{
	int i, row, col, nextRow, nextCol, dir;
	int found = FALSE;

	element position;


	mark[1][1] = 1, top = 0;
	stack[0].row = 1, stack[0].col = 1, stack[0].dir = 1;

	while (top > -1 && !found)
	{
		position = pop();
		row = position.row, col = position.col, dir = position.dir;
		while (dir < 8 && !found)
		{
			nextRow = row + move[dir].vert, nextCol = col + move[dir].horiz;
			if (nextRow == EXIT_ROW && nextCol == EXIT_COL)
				found = TRUE;
			else if (!maze[nextRow][nextCol] && !mark[nextRow][nextCol])
			{
				mark[nextRow][nextCol] = 1;
				position.row = row, position.col = col, position.dir = ++dir;
				push(position);
				row = nextRow, col = nextCol; dir = 0;
			}
			else
				++dir;
		}
	}
	if (found)
	{
		printf("The path is : \n");
		printf("row   col\n");
		for (i = 0; i <= top; i++)
			printf("%2d%5d\n", stack[i].row, stack[i].col);
		printf("%2d%5d\n", row, col);
		printf("%2d%5d\n", EXIT_ROW, EXIT_COL);
	}
	else printf("The maze does not have a path\n");
}

int main()
{
	FILE* fp = fopen("in1.txt", "r");

	if (fp == NULL)
	{
		printf("������ �����ϴ�.");
	}

	else
	{
		for (int i = 0; i < MAX_ROW; i++)
			for (int j = 0; j < MAX_COL; j++)
			{
				maze[i][j] = 1;
				mark[i][j] = 0;
			}

		fscanf(fp, "%d", &EXIT_ROW);
		fscanf(fp, "%d", &EXIT_COL);

		for (int i = 1; i <= EXIT_ROW; i++)
			for (int j = 1; j <= EXIT_COL; j++)
				fscanf(fp, "%d", &maze[i][j]);
		path();
		fclose(fp);
	}

	return 0;
}
