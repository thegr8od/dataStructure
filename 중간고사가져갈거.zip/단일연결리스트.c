#include <stdio.h>
#include <stdlib.h>

typedef struct _node
{
	int data;
	struct _node* next;
}Node;

typedef struct _linkedlist
{
	Node* head;
	int numoflist;
}List;

Node* getnode()
{
	Node* newnode = (Node*)malloc(sizeof(Node));
	newnode->next = NULL;

	return newnode;
}

List* initList()
{
	List* plist = (List*)malloc(sizeof(List));
	plist->head = getnode();
	plist->numoflist = 0;

	return plist;
}

void Insert(List* plist, int data)
{
	Node* newnode = getnode();
	newnode->data = data;

	if (plist->head->next == NULL)
	{
		plist->head->next = newnode;
		return;
	}
	else
	{
		newnode->next = plist->head->next;
		plist->head->next = newnode;
		return;
	}

	(plist->numoflist)++;
}

void search(List* plist, int data)
{
	Node* cur = plist->head;

	if (plist->head->next == NULL)
	{
		printf("������� X\n");
		return;
	}
	else
	{
		while (cur->next != NULL)
		{
			if (cur->data == data)
			{
				printf("ã�� : %d", cur->data);
				return;
			}
			cur = cur->next;
		}
	}
}

void Remove(List* plist, int data)
{
	Node* cur = plist->head;
	Node* rpos;

	if (plist->head->next == NULL)
	{
		printf("��尡 ����\n");
		return;
	}
	else
	{
		while (cur->next != NULL)
		{
			if (cur->next->data == data)
			{
				rpos = cur->next;
				cur->next = cur->next->next;
				free(rpos);
				return;
			}
			cur = cur->next;
		}
	}
	(plist->numoflist)--;
}

void Print(List* plist)
{
	Node* cur;

	if (plist->head->next == NULL)
	{
		printf("������\n");
		return;
	}
	else
	{
		cur = plist->head->next;
		while (cur->next != NULL)
		{
			printf("| %d | => ", cur->data);
			cur = cur->next;
		}
		printf("| %d | => ", cur->data);
	}
}

int main()
{
	int input = 0;
	List* list = initList();

	while (input != -1)
	{
		scanf_s("%d", &input);
		Insert(&list, input);
		if (input == 10)
		{
			Remove(&list, input);
		}
	}
	Print(&list);
}