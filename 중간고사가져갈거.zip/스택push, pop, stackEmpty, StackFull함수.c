#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>
#define SIZE 5

char stack[SIZE];
int top = -1;

int stackFull() {
	if (top >= SIZE - 1) {
		printf("Error : Stack is Full\n");
		return 1;
	}
	return 0;
}

int stackEmpty()
{
	if (top == -1) {
		printf("Error : Stack Empty\n");
		return 1;
	}
	return 0;
}

void push(int data) {
	if (!stackFull()) {
		top++;
		stack[top] = data;
	}
}

int pop() {
	if (!stackEmpty()) {
		int temp = stack[top];
		top--;
		return temp;
	}
}

char peek()
{
	if (!stackEmpty())
	{
		for (int i = 0; i <= top; i++)
			printf("%c ", stack[i]);
	}
	printf("\n");
}

void printStack()
{
	if (!stackEmpty())
	{
		for (int i = 0; i <= top; i++)
			printf("%d ", stack[i]);
	}
	printf("\n");
}


int main()
{
	char ch[10];
	int num;

	while (strcmp(ch, "F"))
	{
		scanf("%s", ch);
		if (strcmp(ch, "I") == 0)
		{
			scanf("%d", &num);
			push(num);
		}
		else if (strcmp(ch, "D") == 0)
			pop();
	}
	printStack();
}