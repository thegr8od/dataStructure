#define _CRT_SECURE_NO_WARNINIGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAX 100
#define FALSE 0
#define TRUE 1

typedef struct humanBeing
{
	char name[MAX];
	int age;
	float salary;
} human;

int humansEqual(human* person1, human* person2)
{
	if (strcmp(person1->name, person2->name))
		return FALSE;
	if (person1->age != person2->age)
		return FALSE;
	if (person1->salary != person2->salary)
		return FALSE;
	return TRUE;
}

int main()
{
	int num;
	human a1 = { "Hong Gil Dong", 40, 350 };
	human a2 = { "Kim Su Mi", 60, 400 };

	printf("Input person1's name, age, salary : \n");
	scanf_s("%[^\n]s ", a1.name, sizeof(a1.name));
	scanf_s("%d", &a1.age);
	scanf_s("%f", &a1.salary);
	fflush(stdin);

	printf("Input person2's name, age, salary : \n");
	scanf_s(" %[^\n]s", a2.name, sizeof(a1.name));
	scanf_s("%d", &a2.age);
	scanf_s("%f", &a2.salary);

	num = humansEqual(&a1, &a2);

	if (num -= 1)
		printf("The two human beings are not the same\n");
	else
		printf("The two human beings are the same\n");

	return 0;
}