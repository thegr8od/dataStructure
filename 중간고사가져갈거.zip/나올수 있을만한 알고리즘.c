//���ڿ� ������ �Լ�
void reverse(char* word) {
	stack_t stack;
	int i;
	for (i = 0; i < strlen(word); i++)
		push(&stack, word[i]);
	i = 0;
	while (!is_empty(&stack))
		word[i++] = pop(&stack);
}

//2������ �ٲٱ� �Լ�
void print_binary(int n)
{
	stack_t stack;
	while (n > 0) 
	{ 
		push(&stack, n % 2); 
		n /= 2; 
	} while (!is_empty(&stack)) 
		printf("%d", pop(&stack));
}

//�־��� ���ڰ� �ſ� ���ڿ����� Ȯ��
int palindrome(char* word)
{
	stack_t stack; 
	int i; 
	init_stack(&stack); 
	for (i = 0; i < strlen(word) / 2; i++) 
		push(&stack, word[i]); 
	if (strlen(word) % 2 > 0) 
		i++; 
	while (!is_empty(&stack)) 
		if (word[i++] != pop(&stack)) 
			return 0; 
	return 1;
}

//��ȣ ¦ �˻�
int paren(char* word)
{
	stack_t stack; 
	int i; 
	init_stack(&stack); 
	for (i = 0; i < strlen(word); i++) 
	{ 
		if (word[i] == '(') push(&stack, word[i]); 
		else if (word[i] == ')') 
			if (pop(&stack) != '(') 
				return 0; 
	} 
	return is_empty(&stack);
}