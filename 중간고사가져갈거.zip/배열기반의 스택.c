#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#define TRUE 1
#define FALSE 0
#define STACK_LEN 100

typedef struct _arraystack
{
	int stackarr[STACK_LEN];
	int topIndex;
} Stack;

void StackInit(Stack* pstack)
{
	pstack->topIndex = -1;
}

int IsEmpty(Stack* pstack)
{
	if (pstack->topIndex == -1)
		return TRUE;
	else
		return FALSE;
}

void push(Stack* pstack, int data)
{
	pstack->topIndex++;
	pstack->stackarr[pstack->topIndex] = data;
}

int pop(Stack* pstack)
{
	int data;

	if (IsEmpty(pstack))
	{
		printf("Stack Memory Error!");
		exit(-1);
	}

	data = pstack->topIndex;
	pstack->topIndex--;

	return pstack->stackarr[data];
}

int peek(Stack* pstack)
{
	if (IsEmpty(pstack))
	{
		printf("Stack Memory Error!");
		exit(-1);
	}
	return pstack->stackarr[pstack->topIndex];
}

int main()
{
	Stack stack;
	StackInit(&stack);

	push(&stack, 1);
	push(&stack, 2);
	push(&stack, 3);
	push(&stack, 4);
	push(&stack, 5);
	push(&stack, 6);

	while (!IsEmpty(&stack))
		printf("%d ", pop(&stack));

	return 0;
}

