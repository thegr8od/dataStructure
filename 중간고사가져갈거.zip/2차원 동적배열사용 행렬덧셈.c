#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#define TRUE 1
#define FALSE 0
#define MAX 100

/* 2���� ���� �迭�� �̿��Ͽ� ��� ������ �׽�Ʈ�ϴ� �ڵ�*/
int** make2dArray(int rows, int cols)
{
	int i;
	int** x = (int**)malloc(sizeof(int));

	for (i = 0; i < rows; i++)
	{
		x = (int**)malloc(sizeof(int) * cols);
	}

	return x;
}

void init2dArray(int a[][MAX], int b[][MAX], int c[][MAX], int rows, int cols)
{
	int i, j;
	a[0][0] = 1; b[0][0] = 2;
	for (int i = 0; i < rows; i++)
	{
		a[i][0] = a[0][0] + i;
		b[i][0] = b[0][0] + i;
		for (int j = 0; j < cols; j++)
		{
			a[i][j] = a[i][0] + j;
			b[i][j] = b[i][0] + j;
			c[i][j] = a[i][j] + b[i][j];
		}
	}
}

void printf2dArray_f(int a[][MAX], int b[][MAX], int c[][MAX], int rows, int cols)
{
	int i, j;
	printf("matrix A\n");
	for (i = 0; i < rows; i++) {
		for (j = 0; j < cols; j++)
		{
			printf("%2d ", a[i][j]);
		}
		printf("\n");
	}

	printf("\n\nmatrix B\n");
	for (i = 0; i < rows; i++) {
		for (j = 0; j < cols; j++)
		{
			printf("%2d ", b[i][j]);
		}
		printf("\n");
	}

	printf("\n\nmatrix C\n");
	for (i = 0; i < rows; i++) {
		for (j = 0; j < cols; j++)
		{
			printf("%2d ", c[i][j]);
		}
		printf("\n");
	}
}

void free2dArray(int rows, int **x)
{
	int i = 0;
	for (i = 0; i < rows; i++)
	{
		free(x[i]);
	}
	printf("2d array - free!!");
}

int main()
{
	int i_rows, i_cols;

	int** arr_1;
	int** arr_2;
	int** arr_3;

	printf("Enter row size and column size ");
	scanf_s("%d %d", &i_rows, &i_cols);
	arr_1 = make2dArray(i_rows, i_cols);
	arr_2 = make2dArray(i_rows, i_cols);
	arr_3 = make2dArray(i_rows, i_cols);
	init2dArray(arr_1, arr_2, arr_3, i_rows, i_cols);
	printf2dArray_f(arr_1, arr_2, arr_3, i_rows, i_cols);
	printf("\n");
	free2dArray(i_rows, arr_1);
	free2dArray(i_rows, arr_2);
	free2dArray(i_rows, arr_3);

	return 0;
}

