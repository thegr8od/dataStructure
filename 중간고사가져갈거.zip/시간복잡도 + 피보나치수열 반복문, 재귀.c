//(unsigned int Ȥ�� unsigned long������ �Լ� / ������ ���� ���� �� �ִ��� 47, int�����θ� �����Ѵٸ� �ִ��� 46.)
#include <stdio.h>
#include <time.h>
#define MAX 100
unsigned int iFibo(int num);
unsigned int rFibo(int num);

int main()
{
	unsigned int temp_2, temp;
	int N, i;
	double start, end, start_2, end_2;
	scanf_s("%d", &N);

	start_2 = (double)clock() / CLOCKS_PER_SEC;

	temp_2 = iFibo(N);
	printf("Iterative F(%d) = %u\n", N, temp_2);

	int sum_2 = 0;
	for (i = 0; i < N; i++)
		sum_2++;
	end_2 = (((double)clock()) / CLOCKS_PER_SEC);
	printf("F(%d) Iterative Time : %lf\n\n", N, (end_2 - start_2));



	start = (double)clock() / CLOCKS_PER_SEC;

	temp = rFibo(N);
	printf("Recursive F(%d) = %u\n", N, temp);


	int sum = 0;
	for (i = 0; i < N; i++)
		sum++;
	end = (((double)clock()) / CLOCKS_PER_SEC);
	printf("F(%d) Recursive Time : %lf\n", N, (end - start));
}


unsigned int iFibo(int num)
{
	unsigned int fn, fn_2 = 0, fn_1 = 1, sum = 0;
	for (int i = 0; i < num; i++)
	{
		fn = fn_2 + fn_1;
		fn_2 = fn_1;
		fn_1 = fn;
	}
	return fn_2;
}

unsigned int rFibo(int num)
{
	int temp = 0;
	if (num <= 1)
		return num;
	else
		return rFibo(num - 1) + rFibo(num - 2);
}