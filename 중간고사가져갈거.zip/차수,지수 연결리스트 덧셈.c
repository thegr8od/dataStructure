#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#define MAX_STACK 100
#define COMPARE(x, y) ((x) < (y) ? -1 : (x) == (y) ? 0 : 1)
#define MALLOC(p,s)\
    if (!((p) = malloc(s))) {\
    	fprintf(stderr, "Insufficient memory.");\
        exit(EXIT_FAILURE);\
    }

typedef struct Node* Pointer;

typedef struct Node {
	int coef;
	int expon;
	Pointer link;
};
Pointer a, b;

Pointer insert(Pointer h, int coef, int expon) {//how to make poly
	Pointer node, P;
	node = malloc(sizeof(*node));
	node->coef = coef;
	node->expon = expon;
	node->link = NULL;

	if (h == NULL)
		h = node;
	else {
		P = h;
		while (P->link != NULL)
			P = P->link;
		P->link = node;
	}
	return h;
}


void attach(float coefficient, int exponent, Pointer* ptr)
{
	Pointer temp;
	MALLOC(temp, sizeof(*temp));
	temp->coef = coefficient;
	temp->expon = exponent;
	(*ptr)->link = temp;
	*ptr = temp; /* move ptr to the end of the list */
}


Pointer padd(Pointer a, Pointer b)
{
	Pointer c, rear, temp;
	int sum;
	MALLOC(rear, sizeof(*rear));
	c = rear;
	while (a && b)
		switch (COMPARE(a->expon, b->expon)) {
		case -1: /* a->expon < b->expon */
			attach(b->coef, b->expon, &rear);
			b = b->link;
			break;
		case 0: /* a->expon == b->expon */
			sum = a->coef + b->coef;
			if (sum)
				attach(sum, a->expon, &rear);
			a = a->link; b = b->link; break;
		case 1: /* a->expon > b->expon */
			attach(a->coef, a->expon, &rear);
			a = a->link;
		}

	/* copy rest of list a and then list b */
	for (; a; a = a->link)
		attach(a->coef, a->expon, &rear);
	//printf("%d  ", rear->coef);
	for (; b; b = b->link)
		attach(b->coef, b->expon, &rear);

	rear->link = NULL;
	/* delete extra initial node */
	temp = c;
	c = c->link;
	free(temp);
	return c;
}

void show(Pointer node)//print polynominal with node
{
	while (node->link != 1) {
		printf("%d %d ", node->coef, node->expon);
		node = node->link;
		if (node->coef >= 0) {
			if (node->link != -1)
				printf("");
		}
	}
}
int main() {

	int x, y;
	Pointer c;

	FILE* fp_1 = fopen("in1.txt", "r");
	if (fp_1 == NULL)
	{
		printf("������ �����ϴ�.\n���α׷��� �����մϴ�.\n");
		return 0;
	}
	else
	{
		while (!feof(fp_1)) {
			fscanf(fp_1, "%d %d", &x, &y);
			a = insert(a, x, y);
		}
	}
	fclose(fp_1);



	FILE* fp_2 = fopen("in2.txt", "r");
	if (fp_2 == NULL)
	{
		printf("������ �����ϴ�.\n���α׷��� �����մϴ�.\n");
		return 0;
	}
	else {
		while (!feof(fp_2)) {
			fscanf(fp_2, "%d %d", &x, &y);
			b = insert(b, x, y);

		}
	}
	fclose(fp_2);

	c = padd(a, b);
	show(c);

	return 0;

}