#define _CRT_SECURE_NO_WARNINGS
#define MAX_TERMS 101 //���� �ִ� ��+1
#include <stdio.h>


typedef struct {
	int col;
	int row;
	int value;
}term;

void transpose(term a[], term b[]);
void matrix(term a[]);

int main() {
	term a_1[MAX_TERMS];
	term b_1[MAX_TERMS];
	FILE* fp_1;

	FILE* fp_2;

	fp_1 = fopen("a.txt", "r");
	if (fp_1 == NULL) {
		printf("���Ͽ��� ����\n");
		return 0;
	}
	else {
		printf("���Ͽ��� ����\n");
	}
	int avail = 0;

	while (!feof(fp_1)) {
		fscanf_s(fp_1, "%d %d %d", &a_1[avail].row, &a_1[avail].col, &a_1[avail].value);
		avail++;
	}




	transpose(a_1, b_1);
	printf("A\n");
	matrix(a_1);
	printf("B\n");
	matrix(b_1);
	fclose(fp_1);




	fp_2 = fopen("b.txt", "w");
	int availw = 0;

	for (int i = 0; i < 9; i++) {
		fprintf(fp_2, "%d %d %d \n", b_1[availw].row, b_1[availw].col, b_1[availw].value);
		availw++;
	}
	fclose(fp_2);

	return 0;
}


void matrix(term a[]) {
	int arr[20][20];
	int num = 1;


	for (int i = 0; i < a[0].row; i++) {
		for (int j = 0; j < a[0].col; j++) {
			if (a[num].row == i && a[num].col == j) {
				arr[i][j] = a[num].value;
				num++;
			}
			else
				arr[i][j] = 0;

		}
	}

	for (int i = 0; i < a[0].row; i++) {
		printf("\n");
		for (int j = 0; j < a[0].col; j++) {
			printf("%d\t", arr[i][j]);

		}
	}
	printf("\n");
}


void transpose(term a[], term b[]) {

	int n, i, j, currentb;
	n = a[0].value;
	b[0].row = a[0].col;
	b[0].col = a[0].row;
	b[0].value = n;

	if (n > 0) {
		currentb = 1;
		for (i = 0; i < a[0].col; i++) {
			for (j = 1; j <= n; j++)

				if (a[j].col == i) {
					b[currentb].row = a[j].col;
					b[currentb].col = a[j].row;
					b[currentb].value = a[j].value;
					currentb++;
				}
		}
	}
}

